<?php
include('config.php');
$phno=$_POST['phno'];
$pwd=$_POST['password'];
$sql= mysqli_query($con,"select password from customer where phno='$phno'");
$scount=mysqli_num_rows($sql);
if($scount==1)
{
	$rs=mysqli_fetch_row($sql);
	if($rs[0]==$pwd)
	{
		session_start();
		$_SESSION["un"]=$name;
		header('Location:index.php');
	}
	else
	{
				echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('For Authorized User Only')
				window.location.href='customer_login.php'
				</SCRIPT>"
				);

	}
}
else
{
	
	echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('For Authorized User Only')
				window.location.href='customer_login.php'
				</SCRIPT>"
				);

}
?>