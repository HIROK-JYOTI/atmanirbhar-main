<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Digital India</title>
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	<link rel="stylesheet" type="text/css" href="css/montserrat-font.css">
	<link rel="stylesheet" type="text/css" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
	<!-- Main Style Css -->
      
      <!--bootstrap css-->
      <!--animate css-->
     
    <link rel="stylesheet" href="css/style4.css"/>
          <link rel="stylesheet" href="css/style.css"/>
          
      <!--responsive css-->

   </head>
	
   

<body class="form-v10">
  <header id="header" class="top-head">
         <!-- Static navbar -->
         <nav class="navbar navbar-default">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-md-4 col-sm-12 left-rs">
                     <div class="navbar-header">
                        
                        <a href="index.php" class="navbar-brand"><img src="images/LOGO.png"  alt="" /></a>
                     </div>
                     
                  </div>
                  <div class="col-md-8 col-sm-12">
                     <div class="right-nav">
                        <div class="login-sr">
                           <div class="login-signup">
                              <ul>
                                 <li><a href="customer_login.php">Login</a></li>
                                 <li><a class="custom-b" href="customer_reg.php">Sign up</a></li>
                              </ul>
                           </div>
                        </div>
                        
                        <div class="nav-b hidden-xs">
                           <div class="nav-box">
                              <ul>
                                 <li><a href="">How it works</a></li>
                                 <li><a href="partner_reg.php">Partners</a>
                                 
                                 
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--/.container-fluid --> 
         </nav>
      </header>
      <!-- Modal -->
<div class="page-content">
		<div class="form-v10-content">
			<form class="form-detail"  enctype="multipart/form-data" method="post" id="myform">
				<div class="form-left">
				<h2>Shipping Details</h2>
					<div class="form-group">
						<div class="form-row form-row-1">
							<img src="images/profession.png">
						</div>
                        </div>	
				</div>
				<div class="form-right">
				
					
					<h2>Shipping Address</h2>
					<div class="form-group">
						<div class="form-row form-row-1">
							<input type="text" name="zipcode" id="zipcode" class="input-text" placeholder="Zip Code" required>
						</div>
						<div class="form-row form-row-2">
							<input type="text" name="hno" id="hno" class="input-text" placeholder="Buliding No/House No" required>
						</div>
					</div>
						<div class="form-row">
						<input type="text" name="street" class="input-text" id="street" placeholder="Street" required>
					</div>
					<div class="form-row">
							<input type="text" name="town" class="input-text" id="town" placeholder="Town/City" required>
					</div>
					<div class="form-row">
						<input type="text" name="country" class="input-text" id="country" placeholder="Country" required>
					</div>
					
					
                 
				
					
					<div class="form-row-last">
						<input type="submit" name="sbmt" class="register" value="Confirm Booking">
					</div>
				</div>
			</form>
		</div>
	</div>
<?php
require_once('config.php');
if(isset($_POST["sbmt"]))
{
	$f1=0;
    $f2=0;
    $f4=0;
    $f4=0;
	$target_dir = "upload_partner/";
	//t1
	$target_file = $target_dir.basename($_FILES["t1"]["name"]);
	$uploadok = 1;
	$imagefiletype = pathinfo($target_file, PATHINFO_EXTENSION);
	//check if image file is a actual image or fake image
	$check=getimagesize($_FILES["t1"]["tmp_name"]);
	//check if file already exists
	if(file_exists($target_file)){
		echo "sorry,file already exists.";
		$uploadok=0;
	}
	//check file size
	if($_FILES["t1"]["size"]>500000){
		echo "sorry, your file is too large.";
		$uploadok=0;
	}
	//aloow certain file formats
	if($imagefiletype != "jpg" && $imagefiletype !="png" && $imagefiletype !="jpeg" && $imagefiletype !="JPG" && $imagefiletype !="JPEG" && $imagefiletype !="PNG"){
		echo "sorry, only jpg,jpeg,png files are allowed.";
		$uploadok=0;
	}else{
		if(move_uploaded_file($_FILES["t1"]["tmp_name"], $target_file)){
			$f1=1;
	} else{
			echo "sorry there was an error uploading your file.";
		}
	}
	//t2
	$target_file = $target_dir.basename($_FILES["t2"]["name"]);
	$uploadok = 1;
	$imagefiletype = pathinfo($target_file, PATHINFO_EXTENSION);
	//check if image file is a actual image or fake image
	$check=getimagesize($_FILES["t2"]["tmp_name"]);
	//check if file already exists
	if(file_exists($target_file)){
		echo "sorry,file already exists.";
		$uploadok=0;
	}
	//check file size
	if($_FILES["t2"]["size"]>500000){
		echo "sorry, your file is too large.";
		$uploadok=0;
	}
	//aloow certain file formats
	if($imagefiletype != "jpg" && $imagefiletype !="png" && $imagefiletype !="jpeg" && $imagefiletype !="JPG" && $imagefiletype !="JPEG" && $imagefiletype !="PNG"){
		echo "sorry, only jpg,jpeg,png files are allowed.";
		$uploadok=0;
	}else{
		if(move_uploaded_file($_FILES["t2"]["tmp_name"], $target_file)){
			$f2=1;
	} else{
			echo "sorry there was an error uploading your file.";
		}
	}
    //t3
	$target_file = $target_dir.basename($_FILES["t3"]["name"]);
	$uploadok = 1;
	$imagefiletype = pathinfo($target_file, PATHINFO_EXTENSION);
	//check if image file is a actual image or fake image
	$check=getimagesize($_FILES["t3"]["tmp_name"]);
	//check if file already exists
	if(file_exists($target_file)){
		echo "sorry,file already exists.";
		$uploadok=0;
	}
	//check file size
	if($_FILES["t3"]["size"]>500000){
		echo "sorry, your file is too large.";
		$uploadok=0;
	}
	//aloow certain file formats
	if($imagefiletype != "jpg" && $imagefiletype !="png" && $imagefiletype !="jpeg" && $imagefiletype !="JPG" && $imagefiletype !="JPEG" && $imagefiletype !="PNG"){
		echo "sorry, only jpg,jpeg,png files are allowed.";
		$uploadok=0;
	}else{
		if(move_uploaded_file($_FILES["t3"]["tmp_name"], $target_file)){
			$f3=1;
	} else{
			echo "sorry there was an error uploading your file.";
		}
	}
    //t4
	$target_file = $target_dir.basename($_FILES["t4"]["name"]);
	$uploadok = 1;
	$imagefiletype = pathinfo($target_file, PATHINFO_EXTENSION);
	//check if image file is a actual image or fake image
	$check=getimagesize($_FILES["t4"]["tmp_name"]);
	//check if file already exists
	if(file_exists($target_file)){
		echo "sorry,file already exists.";
		$uploadok=0;
	}
	//check file size
	if($_FILES["t4"]["size"]>500000){
		echo "sorry, your file is too large.";
		$uploadok=0;
	}
	//aloow certain file formats
	if($imagefiletype != "jpg" && $imagefiletype !="png" && $imagefiletype !="jpeg" && $imagefiletype !="JPG" && $imagefiletype !="JPEG" && $imagefiletype !="PNG"){
		echo "sorry, only jpg,jpeg,png files are allowed.";
		$uploadok=0;
	}else{
		if(move_uploaded_file($_FILES["t4"]["tmp_name"], $target_file)){
			$f4=1;
	} else{
			echo "sorry there was an error uploading your file.";
		}
	}
	
	
	if($f1>0 && $f2>0 && $f3>0 && $f4>0)
		{
	$s="insert into partner(fname,lname,email,gender,aadhar,date,month,year,phno,photo,aadhar_photo,qualification,police_verify,password,re_password,accept) values('" . $_POST["first_name"] . "','" . $_POST["last_name"] . "','" . $_POST["email"] ."','" . $_POST["gender"] ."','" . $_POST["aadhar"] ."','" . $_POST["date"] ."','" . $_POST["month"] ."','" . $_POST["year"] ."','" . $_POST["phno"] ."','" . basename($_FILES["t1"]["name"]) . "','" . basename($_FILES["t2"]["name"]) . "','" . basename($_FILES["t3"]["name"]) . "','" . basename($_FILES["t4"]["name"]) . "','" . $_POST["password"] ."','" . $_POST["re_password"] ."','" . $_POST["accept"] ."')";
	mysqli_query($con,$s);
	echo "<script>alert('Record Save');</script>";
		}
}
?>  
    <footer>
       <div class="copyright">
            <div class="container">
               <div class="row">
                  <div class="col-md-8">
                     <p><img width="90" src="images/LOGO.png" alt="#" style="margin-top: -5px;" /> All Rights Reserved. Company Name © 2021</p>
                  </div>
                 
               </div>
            </div>
         </div>
      </footer>
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/jquery.steps.js"></script>
	<script src="js/main.js"></script>
     <!--main js--> 
   
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>