<?php
session_start();
require_once("config.php");


//code for Cart
if(!empty($_GET["action"])) {
switch($_GET["action"]) {
	//code for adding product in cart
	case "add":
		if(!empty($_POST["quantity"])) {
			$pid=$_GET["pid"];
			$result=mysqli_query($con,"SELECT * FROM product WHERE id='$pid'");
	          while($productByCode=mysqli_fetch_array($result)){
			$itemArray = array($productByCode["code"]=>array('name'=>$productByCode["name"], 'code'=>$productByCode["code"], 'quantity'=>$_POST["quantity"], 'price'=>$productByCode["price"]));
			if(!empty($_SESSION["cart_item"])) {
				if(in_array($productByCode["code"],array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
							if($productByCode["code"] == $k) {
								if(empty($_SESSION["cart_item"][$k]["quantity"])) {
									$_SESSION["cart_item"][$k]["quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			}  else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	}
	break;

	// code for removing product from cart
	case "remove":
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
					if($_GET["code"] == $k)
						unset($_SESSION["cart_item"][$k]);				
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]);
			}
		}
	break;
	// code for if cart is empty
	case "empty":
		unset($_SESSION["cart_item"]);
	break;	
}
}
?>
<HTML>
<HEAD>
<TITLE>Digital India</TITLE>
<link href="css/style1.css" type="text/css" rel="stylesheet" />
  <link rel="stylesheet" href="css/font-awesome.min.css">
      <!--bootstrap css-->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!--animate css-->
      <link rel="stylesheet" href="css/animate-wow.css">
      <!--main css-->
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/bootstrap-select.min.css">
      <link rel="stylesheet" href="css/slick.min.css">
      <!--responsive css-->
      <link rel="stylesheet" href="css/responsive.css">
</HEAD>
<BODY>
  <header id="header" class="top-head">
         <!-- Static navbar -->
         <nav class="navbar navbar-default">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-md-4 col-sm-12 left-rs">
                     <div class="navbar-header">
                        <button type="button" id="top-menu" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false"> 
                        <span class="sr-only">Toggle navigation</span> 
                        <span class="icon-bar"></span> 
                        <span class="icon-bar"></span> 
                        <span class="icon-bar"></span> 
                        </button>
                        <a href="index.php" class="navbar-brand"><img src="images/LOGO.png"  alt="" /></a>
                     </div>
                     <form class="navbar-form navbar-left web-sh">
                        <div class="form">
                           <input type="text" class="form-control" placeholder="Search for products or companies">
                        </div>
                     </form>
                  </div>
                  <div class="col-md-8 col-sm-12">
                     <div class="right-nav">
                        <div class="login-sr">
                           <div class="login-signup">
                              <ul>
                                 
                                 <li><a class="custom-b" href="logout.php">Sign Out</a></li>
                              </ul>
                           </div>
                        </div>
                        
                        <div class="nav-b hidden-xs">
                           <div class="nav-box">
                              <ul>
                                 <li><a href="">How it works</a></li>
                                 <li><a href="partner_reg.php">Register As Partners</a></li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--/.container-fluid --> 
         </nav>
      </header>
      <!-- Modal -->
       <div class="page-content-product">
      
            <div class="container">
  <table align="left">
                    <thead>
                    <tr bordercolor="#000000"> 
                    <th bordercolor="#000000"> <a href="materials.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:#000; font-size:18px;" >Switch & Socket</button></a>
                    </th>
                    <th bordercolor="#000000"> <a href="materials_file.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:#000; font-size:18px;" >Fan</button></a>
                    </th>
                      </th>
                    <th bordercolor="#000000"> <a href="assignment.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:#000; font-size:18px;" >Room Heater</button></a>
                    </th>
                     <th bordercolor="#000000"> <a href="assignment.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:#000; font-size:18px;" >Light</button></a>
                    </th>
                     <th bordercolor="#000000"> <a href="assignment.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:#000; font-size:18px;" >MCB & Fuse</button></a>
                    </th>
                     <th bordercolor="#000000"> <a href="assignment.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:#000; font-size:18px;" >Appliances</button></a>
                    </th>
                     <th bordercolor="#000000"> <a href="assignment.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:#000; font-size:18px;" >Wiring</button></a>
                    </th>
                    </tr>
                    </thead>
            </table>  
          
            </div>
            </div>
<!-- Cart ---->
<div id="shopping-cart">

<div class="txt-heading">
             
</div>

<a id="btnEmpty" href="electrician.php?action=empty">Empty Cart</a>
<a href="book.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:#000; font-size:18px;" >Proceed</button></a>

<?php
if(isset($_SESSION["cart_item"])){
    $total_quantity = 0;
    $total_price = 0;
?>	
<table class="tbl-cart" cellpadding="10" cellspacing="1">
<tbody>
<tr>
<th style="text-align:left;">Name</th>
<th style="text-align:left;">Code</th>
<th style="text-align:right;" width="5%">Quantity</th>
<th style="text-align:right;" width="10%">Unit Price</th>
<th style="text-align:right;" width="10%">Price</th>
<th style="text-align:center;" width="5%">Remove</th>
</tr>	
<?php		
    foreach ($_SESSION["cart_item"] as $item){
        $item_price = $item["quantity"]*$item["price"];
		?>
				<tr>
				<td><?php echo $item["name"]; ?></td>
				<td><?php echo $item["code"]; ?></td>
				<td style="text-align:right;"><?php echo $item["quantity"]; ?></td>
				<td  style="text-align:right;"><?php echo "$ ".$item["price"]; ?></td>
				<td  style="text-align:right;"><?php echo "$ ". number_format($item_price,2); ?></td>
				<td style="text-align:center;"><a href="electrician.php?action=remove&code=<?php echo $item["code"]; ?>" class="btnRemoveAction">Remove</a></td>
				</tr>
				<?php
				$total_quantity += $item["quantity"];
				$total_price += ($item["price"]*$item["quantity"]);
		}
		?>

<tr>
<td colspan="2" align="right">Total:</td>
<td align="right"><?php echo $total_quantity; ?></td>
<td align="right" colspan="2"><strong><?php echo "$ ".number_format($total_price, 2); ?></strong></td>
<td></td>
</tr>
</tbody>
</table>		
  <?php
} else {
?>
<div class="no-records">Your Cart is Empty</div>

<?php 
}
?>
</div>




<div id="product-grid">
	<div class="txt-heading">Services</div>
	<?php
	$product= mysqli_query($con,"SELECT * FROM product ");
	$n=0;
	if (!empty($product)) { 
		while ($row=mysqli_fetch_array($product)) {
			if($n%3==0)
	{
	?>
   <?php
	}
	?>
		<div class="product-item">
        
         
			<form method="post" action="electrician.php?action=add&pid=<?php echo $row["id"]; ?>">
			
			<div class="product-tile-footer">
             
			<div class="product-title"><?php echo $row["name"]; ?></div>
			<div class="product-price"><?php echo "$".$row["price"]; ?></div>
			<div class="cart-action"><input type="text" class="product-quantity" name="quantity" value="1" size="2" /><input type="submit" value="Add to Cart" class="btnAddAction" /></div>
           
			</div>
            
			</form>
           
		</div>
       <?php
		
if($n%3==2)
{
}
$n=$n+1;
}

?>
	
<?php
	}
	else {
 echo "No Records.";

	}
	?>
</div>



</BODY>
</HTML>