<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <title>digital india</title>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!--enable mobile device-->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!--fontawesome css-->
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <!--bootstrap css-->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!--animate css-->
      <link rel="stylesheet" href="css/animate-wow.css">
      <!--main css-->
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/bootstrap-select.min.css">
      <link rel="stylesheet" href="css/slick.min.css">
      <!--responsive css-->
      <link rel="stylesheet" href="css/responsive.css">
   </head>
   <body>
      <header id="header" class="top-head">
         <!-- Static navbar -->
         <nav class="navbar navbar-default">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-md-4 col-sm-12 left-rs">
                     <div class="navbar-header">
                        <button type="button" id="top-menu" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false"> 
                        <span class="sr-only">Toggle navigation</span> 
                        <span class="icon-bar"></span> 
                        <span class="icon-bar"></span> 
                        <span class="icon-bar"></span> 
                        </button>
                        <a href="index.php" class="navbar-brand"><img src="images/LOGO.png"  alt="" /></a>
                     </div>
                     
                  </div>
                  <div class="col-md-8 col-sm-12">
                     <div class="right-nav">
                        <div class="login-sr">
                           <div class="login-signup">
                              <ul>
                                 <li><a href="customer_login.php">Login</a></li>
                                 <li><a class="custom-b" href="customer_reg.php">Sign up</a></li>
                              </ul>
                           </div>
                        </div>
                        
                        <div class="nav-b hidden-xs">
                           <div class="nav-box">
                              <ul>
                                 <li><a href="adminlogin.php">Administrator</a></li>
                                 <li><a href="partner_reg.php">Partners</a>
                                 
                                 
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--/.container-fluid --> 
         </nav>
      </header>
      <!-- Modal -->
     
     
      <div class="page-content-product">
         <div class="main-product">
            <div class="container">
               <div class="row clearfix">
                  <div class="find-box">
                     <h1>Find your next Service or<br>Service Partners here.</h1>
                     <h4>It has never been easier.</h4>
                     <div class="product-sh">
                        <div class="col-sm-6">
                           <div class="form-sh">
                              <input type="text" placeholder="Select Your Current Location" >
                           </div>
                        </div>
                        <div class="col-sm-3">
                           <div class="form-sh">
                              <select class="selectpicker">
                                 <option>Carpenter</option>
                                 <option>Plumber</option>
                                 <option>Electrician</option>
                                 <option>Beautician</option>
                              </select>
                           </div>
                        </div>
                        <div class="col-sm-3">
                           <div class="form-sh"> <a class="btn" href="#">Search</a> </div>
                        </div>
                       <p></p>
                     </div>
                  </div>
               </div>
               <div class="row clearfix">
                  <div class="col-lg-3 col-sm-6 col-md-3">
                     <a href="barbar.php">
                        <div class="box-img">
                           <h4>Barbar</h4>
                           <img src="images/product/barbar.jpeg" alt="" />
                        </div>
                     </a>
                  </div>
                  <div class="col-lg-3 col-sm-6 col-md-3">
                     <a href="">
                        <div class="box-img">
                           <h4>Driver</h4>
                           <img src="images/product/driver.png" alt="" />
                        </div>
                     </a>
                  </div>
                  <div class="col-lg-3 col-sm-6 col-md-3">
                     <a href="">
                        <div class="box-img">
                           <h4>Sweeper</h4>
                           <img src="images/product/sweeper.jpeg" alt="" />
                        </div>
                     </a>
                  </div>
                  <div class="col-lg-3 col-sm-6 col-md-3">
                     <a href="electrician.php">
                        <div class="box-img">
                           <h4>Electrician</h4>
                           <img src="images/product/electrician.jpeg" alt="" />
                        </div>
                     </a>
                  </div>
                  <div class="col-lg-3 col-sm-6 col-md-3">
                     <a href="">
                        <div class="box-img">
                           <h4>Beautician</h4>
                           <img src="images/product/beautician.jpeg" alt="" />
                        </div>
                     </a>
                  </div>
                  <div class="col-lg-3 col-sm-6 col-md-3">
                     <a href="">
                        <div class="box-img">
                           <h4>Carpenter</h4>
                            <img style="height: 260px;" src="images/product/carr.jpg" alt="" />
                        </div>
                     </a>
                  </div>
                  <div class="col-lg-3 col-sm-6 col-md-3">
                     <a href="l">
                        <div class="box-img">
                           <h4>Plumber</h4>
                            <img style="height: 260px;" src="images/product/plum.jpeg" alt="" />
                        </div>
                     </a>
                  </div>
                  <div class="col-lg-3 col-sm-6 col-md-3">
                     <a href="">
                        <div class="box-img">
                           <h4>AC Repairing</h4>
                       <img style="height: 260px;" src="images/product/ac.jpg" alt="" />
                        </div>
                     </a>
                  </div>
                  <div class="categories_link">
                     <a href="#">Browse all categories here</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="cat-main-box">
         <div class="container">
            <div class="row panel-row">
               <div class="col-md-4 col-sm-6 wow fadeIn" data-wow-delay="0.0s">
                  <div class="panel panel-default">
                     <div class="panel-body">
                        
                        <h4>Service Gurantee</h4>
                        <p>Customer protection 
                        </p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6 wow fadeIn" data-wow-delay="0.2s">
                  <div class="panel panel-default">
                     <div class="panel-body">
                       
                        <h4>Expert Technicians</h4>
                        <p>Background Checked ,Authenticated with Aadhar and Trained Technicians
                        </p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4 col-sm-6 wow fadeIn hidden-sm" data-wow-delay="0.4s">
                  <div class="panel panel-default">
                     <div class="panel-body">
                      
                        <h4>Unparalleled growth</h4>
                        <p>Limitless opportunities 
                        </p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="products_exciting_box">
         <div class="container">
            <div class="row">
               <div class="col-md-6 col-sm-6 wow fadeIn" data-wow-delay="0.2s">
                  <div class="exciting_box f_pd">
                     <img src="images/exciting_img-01.jpg" class="icon-small" alt="" />
                     <h4>Explore <strong>exciting</strong> and exotic services
                        tailored to you.
                     </h4>
                     <p>
                     </p>
                  </div>
               </div>
               <div class="col-md-6 col-sm-6 wow fadeIn" data-wow-delay="0.4s">
                  <div class="exciting_box l_pd">
                     <img src="images/exciting_img-02.jpg" class="icon-small" alt="" />
                     <h4><strong>Get Exciting offers</strong> and grow connections.</h4>
                     <p>
                     </p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   
          
          
     
      <footer>
         <div class="main-footer">
            <div class="container">
               <div class="row">
                  <div class="footer-top clearfix">
                     <div class="col-md-2 col-sm-6">
                        <h2>Enter Your Queries
                        </h2>
                     </div>
                     <div class="col-md-6 col-sm-6">
                        <div class="form-box">
                           <input type="text" placeholder="Enter yopur e-mail" />
                           <button>Continue</button>
                        </div>
                     </div>
                     <div class="col-md-4 col-sm-12">
                        <div class="help-box-f">
                           <h4>Question? Call us on  for help</h4>
                           <p>Easy setup - no payment fees </p>
                        </div>
                     </div>
                  </div>
                  <div class="footer-link-box clearfix">
                     <div class="col-md-6 col-sm-6">
                        <div class="left-f-box">
                           <div class="col-sm-4">
                              <h2>Service Partners</h2>
                              <ul>
                                 <li><a href="#">About Partners</a></li>
                                 <li><a href="howitworks.html">How it works</a></li>
                                 <li><a href="pricing.html">Pricing</a></li>
                                 <li><a href="#">FAQ for Partners</a></li>
                              </ul>
                           </div>
                           <div class="col-sm-4">
                              <h2>Customers</h2>
                              <ul>
                                 <li><a href="#">About Customers</a></li>
                                 <li><a href="#">How it works</a></li>
                                 <li><a href="#">Categories</a></li>
                                 <li><a href="#">FAQ for customers</a></li>
                              </ul>
                           </div>
                           <div class="col-sm-4">
                              <h2>Terms & Conditions</h2>
                              <ul>
                                 <li><a href="about-us.html">Privacy policy</a></li>
                                 <li><a href="#">Anti Discrimination Policy</a></li>
                                 <li><a href="#">Contact us</a></li>
                              </ul>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-6 col-sm-6">
                        <div class="right-f-box">
                           <h2>Serving In</h2>
                           <ul class="col-sm-4">
                              <li><a href="#">Guwahati</a></li>
                              <li><a href="#">Barpeta</a></li>
                              <li><a href="#">Rangia</a></li>
                              <li><a href="#">Nalbari</a></li>
                              <li><a href="#">Tinsukia</a></li>
                           </ul>
                           <ul class="col-sm-4">
                              <li><a href="#">Dhemaji</a></li>
                              <li><a href="#">Dibrugarh</a></li>
                             
                           </ul>
                           <ul class="col-sm-4">
                             
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="copyright">
            <div class="container">
               <div class="row">
                  <div class="col-md-8">
                     <p><img width="90" src="images/LOGO.png" alt="#" style="margin-top: -5px;" /> All Rights Reserved. Company Name © 2021</p>
                  </div>
                 
               </div>
            </div>
         </div>
      </footer>
      <!--main js--> 
      <script src="js/jquery-1.12.4.min.js"></script> 
      <!--bootstrap js--> 
      <script src="js/bootstrap.min.js"></script> 
      <script src="js/bootstrap-select.min.js"></script>
      <script src="js/slick.min.js"></script> 
      <script src="js/wow.min.js"></script>
      <!--custom js--> 
      <script src="js/custom.js"></script>
   </body>
</html>