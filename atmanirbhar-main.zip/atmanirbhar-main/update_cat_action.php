<?php
	include('regconnection.php');
	
if(isset($_POST['submit'])){
    $cat_id=$_POST['cat_id'];
	
    $category=$_POST['category'];
    
	

 $r="update category set category='$category' where cat_id='$cat_id'";

      $res=mysqli_query($con,$r) or die(mysqli_connect_error());

if($res)
{
		echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Successful')
				window.location.href='update_cat.php'
				</SCRIPT>"
				);
	
}
else
{
		echo("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('Try Again')
				window.location.href='update_cat_mid.php'
				</SCRIPT>"
				);
}
}
	?>			