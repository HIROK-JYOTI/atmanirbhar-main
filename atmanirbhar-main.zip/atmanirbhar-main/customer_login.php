
     
    <link rel="stylesheet" href="css/style4.css"/>
   

<body class="form-v10">
 
<div class="page-content">
      <div class="form-v10-content">
         <form class="form-detail"   method="post" id="myform" action="cust_login_action.php">
            <div class="form-left">
               <h2>Login here</h2>
               <div class="form-group">
                  <div class="form-row form-row-1">
                     <img src="images/profession.png">
                  </div>
                  
               </div>
               
                   
                  </div>
            <div class="form-right">
               <h2>  Login Information</h2>
               <div class="form-row">
                  <input type="text" name="adminid" id="phno" class="input-text" placeholder="Your User Name">
               </div>
                    <div class="form-row">
                     <input type="password" name="password" id="password" class="input-text" placeholder="Your Password">
               </div>
               
               <div class="form-row-last">
                  <input type="submit" name="submit" class="login" value="Sign In">
               </div>
            </div>
         </form>
      </div>
   </div>

   
   
</body>
</html>