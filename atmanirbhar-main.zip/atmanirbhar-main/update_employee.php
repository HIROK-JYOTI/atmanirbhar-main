<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Atma Nirbhar Services</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="stylesheet/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="container">
  <div class="banner">
    <div class="banner-left">
    <div class="logozone"> <img src="images/logo1.PNG" height="60" width="300" alt="" border="0" /> </div>
      <div style="padding:203px 0px 0px 0px">
        <div class="topmenuzone">
          <div class="mainmenu">
            <ul>
              <li><a href="adminindex.php">HOME</a></li>
              <li><a href="category.php">CATEGORY</a></li>
             
              <li><a href="employee.php">EMPLOYEE</a></li>
                <li><a href="view_req_emp.php">APPROVAL</a></li>
                 <li><a href="view_feedback.php">FEEDBACK</a></li>
              <li style="border:none;"><a href="">BOOKING</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="banner-right">
      <div class="rightmenu">
        <div class="rightmenu1 rightmenulink"> <a href="index.html">Home</a> </div>
        <div class="rightmenu2 rightmenulink"> <a href="adminindex.html">Admin</a> </div>
        <div class="rightmenu3 rightmenulink"> <a href="logout.php">Logout</a> </div>
        <div class="clear"></div>
      </div>
      <div class="clear"></div>
      <div style="padding-top:15px; float:left">
        <div class="contactzone">
          <div class="contactleft"> <img src="images/contact.png" alt="" /> </div>
         <div class="contactright"><strong>Atma Nirbhar Services</strong><br />
          
            Silchar-06,Cachar ,Assam<br />
            <br />
            <span class="blueboldtxt">Phone:</span> +91-9435849354 <br />
            <span class="blueboldtxt">e-mail:</span> <span class="orangeboldtxt">atmanirbharservices<br/>@gmail.com</span></div>
          <div class="clear"></div>
        </div>
      </div>
    </div>
    <div class="clear"></div>
  </div>
  <div class="clear"></div>
  <div class="workzone">
    <div class="workzone-left">
      <div style="width:900px;">
        <div class="welcomezone">
          <div class="welcomeheading">
            <div>
              <h1>WELCOME TO <br />
                <span>Atma Nirbhar Services</span></h1>
            </div>
          </div>
           <div><font size="2" color="#000000">The service is offered through our website and you can hire professionals for pest control, carpentry, plumbing, professional cleaning, carpet and sofa cleaning, electrical repairs, laundry, home spa, and more. <br />
            <br />
           The company evaluates the eligibility of all enlisted service providers so that you can rest your worries. We also provide additional training and counseling for bridging any gap that exists in their service. </font></div>
          <div class="clear"></div>
        </div>
        <div class="clear"></div>
        <div class="box1">
          <div class="clientimg"></div>
          <div>
            <h2>WELCOME<span class="blueheading22">ADMIN<BR/></span> <span> TO OUR PORTAL</span></h2>
          </div>
          <div> <br />
           <?php

require_once('regconnection.php');

if(isset($_POST["sbmt"]))
{
	
	$f1=0;
	$f2=0;
	
	$target_dir = "requestimages/";
	//t8
	$target_file = $target_dir.basename($_FILES["t8"]["name"]);
	$uploadok = 1;
	$imagefiletype = pathinfo($target_file, PATHINFO_EXTENSION);
	
	
	

		if(move_uploaded_file($_FILES["t8"]["tmp_name"], $target_file)){
			$f1=1;
	} 	

	
	//t9
	$target_file = $target_dir.basename($_FILES["t9"]["name"]);
	$uploadok = 1;
	$imagefiletype = pathinfo($target_file, PATHINFO_EXTENSION);
	
		if(move_uploaded_file($_FILES["t9"]["tmp_name"], $target_file)){
			$f2=1;
	} 	

	
	
	
	
}
	 
?>

<?php
require_once('regconnection.php');
if(isset($_POST["sbmt"]))
{
	
	
	if (empty($_FILES['t3']['name'])) {
	
		$s="update reg_employee set name='" . $_POST["t1"] ."',Category='" . $_POST["t2"] . "',district='" . $_POST["t3"] . "',pin='" . $_POST["t4"] . "',qualification='" . $_POST["t5"] . "',experience='" . $_POST["t6"] . "',mobile='" . $_POST["t7"] . "',pic1='" . $_POST["h1"] . "',pic2='" . $_POST["h2"]. "' where e_id='" . $_POST["s1"] . "'";
	
}
else
{
	
	
	$s="update reg_employee set name='" . $_POST["t1"] ."',Category='" . $_POST["t2"] . "',district='" . $_POST["t3"] . "',pin='" . $_POST["t4"] . "',qualification='" . $_POST["t5"] . "',experience='" . $_POST["t6"] . "',mobile='" . $_POST["t7"] . "',pic1='" .  basename($_FILES["t8"]["name"]) . "',pic2='" .  basename($_FILES["t9"]["name"]) . "' where e_id='" . $_POST["s1"] . "'";}
	mysqli_query($con,$s);
	
	echo "<script>alert('Record Update');</script>";
    }

?>
  
                  <form method="POST" enctype="multipart/form-data"> 
                  
                <table id="example" width="100%" cellspacing="0">
        
            <tr >
              <td class="lefttxt"><font color="#000000">Select Employee</font></td><td><select name="s1" class="form-control" /><option value="">Select</option>

<?php
	require_once('regconnection.php');
$s="select * from reg_employee";
$result=mysqli_query($con,$s);
$r=mysqli_num_rows($result);
//echo $r;

while($data=mysqli_fetch_array($result))
{
	if(isset($_POST["show"])&& $data[0]==$_POST["s1"])
	{
		echo"<option value=$data[0] selected>$data[1]</option>";
	}
	else
	{
		echo "<option value=$data[0]>$data[1]</option>";
	}
}




?>

</select>
<input type="submit" value="Show" name="show" formnovalidate/>
<?php
if(isset($_POST["show"]))
{
require_once('regconnection.php');
$s="select * from reg_employee where e_id='" .$_POST["s1"] ."'";
$result=mysqli_query($con,$s);
$r=mysqli_num_rows($result);
//echo $r;

$data=mysqli_fetch_array($result);
$e_id=$data[0];
$name=$data[1];
$category=$data[2];
$district=$data[3];
$pin=$data[4];
$qualification=$data[5];
$experience=$data[6];
$mobile=$data[7];
$pic1=$data[8];
$pic2=$data[9];




}

?>

</td></tr>

<tr><td class="lefttxt"><font color="#000000">Employee Name</font></td><td><input type="text"  value="<?php if(isset($_POST["show"])){ echo $name ;} ?> " name="t1" class="form-control" required pattern="[a-zA-z _]{1,50}" title="Please Enter Only Characters between 1 to 50 for  Name"/></td></tr>
<tr><td class="lefttxt"><font color="#000000">District</font></td><td><input type="text" name="t2" class="form-control" value="<?php if(isset($_POST["show"])){ echo $category ;} ?> " /></td></tr>

<tr><td class="lefttxt"><font color="#000000">District</font></td><td><input type="text" name="t3" class="form-control" value="<?php if(isset($_POST["show"])){ echo $district ;} ?> " /></td></tr>
<tr><td class="lefttxt"><font color="#000000">Pin</font></td><td><input type="text" name="t4" class="form-control" value="<?php if(isset($_POST["show"])){ echo $pin ;} ?> " /></td></tr>
<tr><td class="lefttxt"><font color="#000000">Qualification</font></td><td><input type="text" name="t5" class="form-control" value="<?php if(isset($_POST["show"])){ echo $qualification ;} ?> " /></td></tr>
<tr><td class="lefttxt"><font color="#000000">Experience</font></td><td><input type="text" name="t6" class="form-control" value="<?php if(isset($_POST["show"])){ echo $experience ;} ?> " /></td></tr>
<tr><td class="lefttxt"><font color="#000000">Mobile Number</font></td><td><input type="text" name="t7" class="form-control"  value="<?php if(isset($_POST["show"])){ echo $mobile ;} ?> " /></td></tr>

<tr><td class="lefttxt"><font color="#000000">Upload Photo</font></td><td><input type="file" name="t8"class="form-control" /></td></tr>

<tr><td class="lefttxt"><font color="#000000">Old Pic</font></td><td><img src="requestimages/<?php echo @$pic1; ?>" width="150px" height="100px" />
<input type="hidden" name="h1" value="<?php if(isset($_POST["show"])) {echo $pic1;} ?>" />
</td></tr>
<tr><td class="lefttxt"><font color="#000000">Upload Document</font></td><td><input type="file" name="t9" class="form-control" /></td></tr>

<tr><td class="lefttxt"><font color="#000000">Old Pic</font></td><td><img src="requestimages/<?php echo @$pic2; ?>" width="150px" height="100px" />
<input type="hidden" name="h2" value="<?php if(isset($_POST["show"])) {echo $pic2;} ?>" />
</td></tr>


<tr><td>&nbsp;</td><td ><input type="submit" value="Update" name="sbmt" /></td></tr>




</table>
</form>         
           </div>
          <div class="clear"></div>
        </div>
        <div class="clear"></div>
        <div class="box2">
          
          
          <div class="clear"></div>
        </div>
        <div class="clear"></div>
      </div>
    </div>
    <div class="clear"></div>
  </div>
  <div class="clear"></div>
  <div class="footer">
    <div class="footerlink"> Copyright (@)2020.. All rights reserved. Design by Unique Team </div>
  </div>
  <div class="clear"></div>
</div>
</body>
</html>
