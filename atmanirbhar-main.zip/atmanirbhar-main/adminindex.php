
     
    <link rel="stylesheet" href="css/style4.css"/>
   

<body class="form-v10">
 
<div class="page-content">
		<div class="form-v10-content">
			
				<table align="left">
                    <thead>
                    <tr bordercolor="#000000"> 
                    <th> <a href="category.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:#FFF; font-size:18px;" >Category</button></a>
                    </th>
                    <th bordercolor="#000000"> <a href="employee.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:#FFF; font-size:18px;" >Employee</button></a>
                    </th>
                      </th>
                    <th bordercolor="#000000"> <a href="approval.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:#FFF; font-size:18px;" >Approval</button></a>
                    </th>
                     <th bordercolor="#000000"> <a href="book.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:#FFF; font-size:18px;" >Bookings</button></a>
                    </th>
                    </tr>
                    </thead>
            </table>          
				
		</div>
	</div>

   
   
</body>
</html>