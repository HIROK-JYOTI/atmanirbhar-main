
<link rel="stylesheet" href="css/style4.css"/>
<?php 
  
   require_once('config.php');
   if(isset($_POST["sbmt"]))
   {
      
      $s="insert into customer(fname,lname,phno,email,password,re_password,accept) values('" . $_POST["first_name"] . "','" . $_POST["last_name"] . "','" . $_POST["phno"] ."','" . $_POST["email"] ."','" . $_POST["password"] ."','" . $_POST["re_password"] ."','" . $_POST["accept"] ."')";
      mysqli_query($con,$s);
      echo "<script>alert('Record Save');</script>";
   }

?>
 
 <body class="form-v10">
<div class="page-content">
		<div class="form-v10-content">
			<form class="form-detail"  enctype="multipart/form-data" method="post" id="myform">
				<div class="form-left">
					<h2>General Infomation</h2>
					<div class="form-group">
						<div class="form-row form-row-1">
							<input type="text" name="first_name" id="first_name" class="input-text" placeholder="First Name" required>
						</div>
						<div class="form-row form-row-2">
							<input type="text" name="last_name" id="last_name" class="input-text" placeholder="Last Name" required>
						</div>
					</div>
               <div class="form-row">
						<input type="text" name="email" class="input-text" id="email" placeholder="Email Address" required>
					</div>  
               <div class="form-row">
						<input type="text" name="phno"  id="phno" placeholder="Phone Number" required>
					</div>
               <div class="form-group">
						<div class="form-row form-row-1">
                     <input type="text" name="otp"  id="otp" placeholder="OTP">
						</div>
                  <div class="form-row form-row-2">
                     <button type="submit" name="verify" class="btn btn-primary btn-xl text-uppercase" value="Verify OTP">Verify OTP</button>
						</div>
               </div>
				</div>
				<div class="form-right">
					<h2>  Security Information</h2>
					<div class="form-row">
						<input type="password" name="password" id="password" class="input-text" placeholder="Your Password">
					</div>
               <div class="form-row">
						<input type="password" name="re_password" id="re_password" class="input-text" placeholder="Retype Password">
					</div>
					<div class="form-checkbox">
						<label class="container"><p>I do accept the <a href="condition.php" class="text">Terms and Conditions</a> of your site.</p>
						  	<input type="checkbox" name="accept">
						  	<span class="checkmark"></span>
						</label>
					</div>
					<div class="form-row-last">
						<input type="submit" name="sbmt" class="register" value="Register">
				  </div>
				</div>
			</form>
		</div>
	</div>
</body>

