
	
     
    <link rel="stylesheet" href="css/style4.css"/>
         
     

<body class="form-v10">

      
<div class="page-content">
		<div class="form-v10-content">
			<form class="form-detail"  enctype="multipart/form-data" method="post" id="myform">
				<div class="form-left">
					<h2>General Infomation</h2>
					<div class="form-group">
						<div class="form-row form-row-1">
							<input type="text" name="first_name" id="first_name" class="input-text" placeholder="First Name" required>
						</div>
						<div class="form-row form-row-2">
							<input type="text" name="last_name" id="last_name" class="input-text" placeholder="Last Name" required>
						</div>
					</div>
						<div class="form-row">
						<input type="text" name="email" class="input-text" id="email" placeholder="Email Address" required>
					</div>
					<div class="form-row">
						<select name="gender">
						    <option value="select">Gender</option>
						    <option value="male">Male</option>
						    <option value="female">Female</option>
						    <option value="other">Others</option>
						</select>
						<span class="select-btn">
						  	<i class="zmdi zmdi-chevron-down"></i>
						</span>
					</div>
					<div class="form-row">
						<input type="text" name="aadhar" class="input-text" id="aadhar" placeholder="Aadhar Number" required>
					</div>
					<div class="form-group">
					<div class="form-row form-row-4">
							<input type="text" name="dob" class="input-text" id="dob" placeholder="DOB">	
						</div>
                    	<div class="form-row form-row-4">
							<select name="date">
							    <option value="select">DD</option>
                                <option value="1">1</option>
							    <option value="2">2</option>
							    <option value="3">3</option>
							    <option value="4">4</option>
                                 <option value="5">5</option>
                                  <option value="6">6</option>
                                   <option value="7">7</option>
                                    <option value="8">8</option>
                                     <option value="9">9</option>
                                      <option value="10">10</option>
                                       <option value="11">11</option>
                                        <option value="12">12</option>
                                         <option value="13">13</option>
                                          <option value="14">14</option>
                                           <option value="15">15</option>
                                            <option value="16">16</option>
                                             <option value="17">17</option>
                                              <option value="18">18</option>
							</select>
							<span class="select-btn">
							  	<i class="zmdi zmdi-chevron-down"></i>
							</span>
						</div>
						<div class="form-row form-row-4">
							<select name="month">
							    <option value="select">MM</option>
							    <option value="jan">Jan</option>
							    <option value="colleague">Feb</option>
							    <option value="associate">Mar</option>
                                  <option value="associate">Apr</option>
                                    <option value="associate">May</option>
                                      <option value="associate">Jun</option>
                                       <option value="associate">Jul</option>
                                        <option value="associate">Aug</option>
                                        <option value="associate">Sept</option>
                                          <option value="associate">Oct</option>
                                            <option value="associate">Nov</option>
                                            <option value="associate">Dec</option>
							</select>
							<span class="select-btn">
							  	<i class="zmdi zmdi-chevron-down"></i>
							</span>
						</div>
                        <div class="form-row form-row-4">
							<select name="year">
							    <option value="employees">YYYY</option>
							    <option value="trainee">2000</option>
							    <option value="colleague">2001</option>
							    <option value="associate">2002</option>
							</select>
							<span class="select-btn">
							  	<i class="zmdi zmdi-chevron-down"></i>
							</span>
						</div>
					</div>
                    <div class="form-row">
						<input type="text" name="phno" class="company" id="phno" placeholder="Phone Number" required>
					</div>
                   <div class="form-group">
						<div class="form-row form-row-4">
								<input type="text" name="otp" class="company" id="otp" placeholder="OTP">
							
						</div>
                        <div class="form-row form-row-4">
								<input type="Submit" name="company" class="company" value="Verify OTP">
							
						</div>
                        </div>
                        
				</div>
				<div class="form-right">
					<h2> Upload Documents & Security Info</h2>
					<div class="form-group">
						<div class="form-row form-row-1">
							<input type="text" name="zip" class="zip" id="zip" placeholder="Photo" >
						</div>
						<div class="form-row form-row-2">
							<input type="file" name="t1" required>
						
						</div>
					</div>
					<div class="form-group">
						<div class="form-row form-row-1">
							<input type="text" name="zip" class="zip" id="zip" placeholder="Aadhar" >
						</div>
						<div class="form-row form-row-2">
								<input type="file" name="t2"  required>
						</div>
					</div>
					<div class="form-group">
						<div class="form-row form-row-1">
							<input type="text" name="zip" class="zip" id="zip" placeholder="Qualification" >
						</div>
						<div class="form-row form-row-2">
								<input type="file" name="t3"   required>
						</div>
					</div>
					<div class="form-group">
						<div class="form-row form-row-1">
							<input type="text" name="zip" class="zip" id="zip" placeholder="Police Verify" >
						</div>
						<div class="form-row form-row-2">
								
                                <input type="file" name="t4"  placeholder="Police Verify" required>
						</div>
					</div>
                  <div class="form-row">
							<a href="images/format.pdf"><font size="+1" color="#FFFFFF">Download Format for verification here</font></a>
						</div>
						
					
					<div class="form-row">
						<input type="password" name="password" id="password" class="input-text" placeholder="Your Password">
					</div>
                    <div class="form-row">
						<input type="password" name="re_password" id="re_password" class="input-text" placeholder="Retype Password">
					</div>
					<div class="form-checkbox">
						<label class="container"><p>I do accept the <a href="condition.php" class="text">Terms and Conditions</a> of your site.</p>
						  	<input type="checkbox" name="accept">
						  	<span class="checkmark"></span>
						</label>
					</div>
					<div class="form-row-last">
						<input type="submit" name="sbmt" class="register" value="Register Partner">
					</div>
				</div>
			</form>
		</div>
	</div>
<?php
require_once('config.php');
if(isset($_POST["sbmt"]))
{
	$f1=0;
    $f2=0;
    $f4=0;
    $f4=0;
	$target_dir = "upload_partner/";
	//t1
	$target_file = $target_dir.basename($_FILES["t1"]["name"]);
	$uploadok = 1;
	$imagefiletype = pathinfo($target_file, PATHINFO_EXTENSION);
	//check if image file is a actual image or fake image
	$check=getimagesize($_FILES["t1"]["tmp_name"]);
	//check if file already exists
	if(file_exists($target_file)){
		echo "sorry,file already exists.";
		$uploadok=0;
	}
	//check file size
	if($_FILES["t1"]["size"]>500000){
		echo "sorry, your file is too large.";
		$uploadok=0;
	}
	//aloow certain file formats
	if($imagefiletype != "jpg" && $imagefiletype !="png" && $imagefiletype !="jpeg" && $imagefiletype !="JPG" && $imagefiletype !="JPEG" && $imagefiletype !="PNG"){
		echo "sorry, only jpg,jpeg,png files are allowed.";
		$uploadok=0;
	}else{
		if(move_uploaded_file($_FILES["t1"]["tmp_name"], $target_file)){
			$f1=1;
	} else{
			echo "sorry there was an error uploading your file.";
		}
	}
	//t2
	$target_file = $target_dir.basename($_FILES["t2"]["name"]);
	$uploadok = 1;
	$imagefiletype = pathinfo($target_file, PATHINFO_EXTENSION);
	//check if image file is a actual image or fake image
	$check=getimagesize($_FILES["t2"]["tmp_name"]);
	//check if file already exists
	if(file_exists($target_file)){
		echo "sorry,file already exists.";
		$uploadok=0;
	}
	//check file size
	if($_FILES["t2"]["size"]>500000){
		echo "sorry, your file is too large.";
		$uploadok=0;
	}
	//aloow certain file formats
	if($imagefiletype != "jpg" && $imagefiletype !="png" && $imagefiletype !="jpeg" && $imagefiletype !="JPG" && $imagefiletype !="JPEG" && $imagefiletype !="PNG"){
		echo "sorry, only jpg,jpeg,png files are allowed.";
		$uploadok=0;
	}else{
		if(move_uploaded_file($_FILES["t2"]["tmp_name"], $target_file)){
			$f2=1;
	} else{
			echo "sorry there was an error uploading your file.";
		}
	}
    //t3
	$target_file = $target_dir.basename($_FILES["t3"]["name"]);
	$uploadok = 1;
	$imagefiletype = pathinfo($target_file, PATHINFO_EXTENSION);
	//check if image file is a actual image or fake image
	$check=getimagesize($_FILES["t3"]["tmp_name"]);
	//check if file already exists
	if(file_exists($target_file)){
		echo "sorry,file already exists.";
		$uploadok=0;
	}
	//check file size
	if($_FILES["t3"]["size"]>500000){
		echo "sorry, your file is too large.";
		$uploadok=0;
	}
	//aloow certain file formats
	if($imagefiletype != "jpg" && $imagefiletype !="png" && $imagefiletype !="jpeg" && $imagefiletype !="JPG" && $imagefiletype !="JPEG" && $imagefiletype !="PNG"){
		echo "sorry, only jpg,jpeg,png files are allowed.";
		$uploadok=0;
	}else{
		if(move_uploaded_file($_FILES["t3"]["tmp_name"], $target_file)){
			$f3=1;
	} else{
			echo "sorry there was an error uploading your file.";
		}
	}
    //t4
	$target_file = $target_dir.basename($_FILES["t4"]["name"]);
	$uploadok = 1;
	$imagefiletype = pathinfo($target_file, PATHINFO_EXTENSION);
	//check if image file is a actual image or fake image
	$check=getimagesize($_FILES["t4"]["tmp_name"]);
	//check if file already exists
	if(file_exists($target_file)){
		echo "sorry,file already exists.";
		$uploadok=0;
	}
	//check file size
	if($_FILES["t4"]["size"]>500000){
		echo "sorry, your file is too large.";
		$uploadok=0;
	}
	//aloow certain file formats
	if($imagefiletype != "jpg" && $imagefiletype !="png" && $imagefiletype !="jpeg" && $imagefiletype !="JPG" && $imagefiletype !="JPEG" && $imagefiletype !="PNG"){
		echo "sorry, only jpg,jpeg,png files are allowed.";
		$uploadok=0;
	}else{
		if(move_uploaded_file($_FILES["t4"]["tmp_name"], $target_file)){
			$f4=1;
	} else{
			echo "sorry there was an error uploading your file.";
		}
	}
	
	
	if($f1>0 && $f2>0 && $f3>0 && $f4>0)
		{
	$s="insert into partner(fname,lname,email,gender,aadhar,date,month,year,phno,photo,aadhar_photo,qualification,police_verify,password,re_password,accept) values('" . $_POST["first_name"] . "','" . $_POST["last_name"] . "','" . $_POST["email"] ."','" . $_POST["gender"] ."','" . $_POST["aadhar"] ."','" . $_POST["date"] ."','" . $_POST["month"] ."','" . $_POST["year"] ."','" . $_POST["phno"] ."','" . basename($_FILES["t1"]["name"]) . "','" . basename($_FILES["t2"]["name"]) . "','" . basename($_FILES["t3"]["name"]) . "','" . basename($_FILES["t4"]["name"]) . "','" . $_POST["password"] ."','" . $_POST["re_password"] ."','" . $_POST["accept"] ."')";
	mysqli_query($con,$s);
	echo "<script>alert('Record Save');</script>";
		}
}
?>  
    
   
</body>
</html>