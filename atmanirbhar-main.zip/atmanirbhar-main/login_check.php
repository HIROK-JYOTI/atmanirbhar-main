<?php
include('config.php');
$userid=$_POST['adminid'];
$pwd=$_POST['password'];
$sql= mysqli_query($con,"select password from admin where admin_id='$userid'");
$scount=mysqli_num_rows($sql);
if($scount==1)
{
	$rs=mysqli_fetch_row($sql);
	if($rs[0]==$pwd)
	{
		session_start();
		$_SESSION["un"]=$userid;
		header('Location:adminindex.php');
	}
	else
	{
				echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('For Authorized User Only')
				window.location.href='adminlogin.php'
				</SCRIPT>"
				);

	}
}
else
{
	
	echo ("<SCRIPT LANGUAGE='JavaScript'>
				window.alert('For Authorized User Only')
				window.location.href='adminlogin.php'
				</SCRIPT>"
				);

}
?>