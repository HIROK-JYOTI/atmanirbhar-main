<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Digital India</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link rel="stylesheet" type="text/css" href="css/montserrat-font.css">
	<link rel="stylesheet" type="text/css" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/style4.css"/>
    <link rel="stylesheet" href="css/style.css"/>
    <link rel="stylesheet" href="css/font-awesome.min.css">
   <!-- <link rel="stylesheet" href="css/bootstrap.min.css"> -->
   <link rel="stylesheet" href="css/animate-wow.css">
   <link rel="stylesheet" href="css/bootstrap-select.min.css">
   <link rel="stylesheet" href="css/slick.min.css">
   <link rel="stylesheet" href="css/responsive.css">
</head>
<body class="form-v10">
    <header id="header" class="top-head">
         <!-- Static navbar -->
        <nav class="navbar navbar-default">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-md-4 col-sm-12 left-rs">
                     <div class="navbar-header">
                        <a href="index.php" class="navbar-brand"><img src="images/LOGO.png"  alt="" /></a>
                     </div> 
                  </div>
                  <div class="col-md-8 col-sm-12">
                     <div class="right-nav">
                        <div class="login-sr">
                           <div class="login-signup">
                              <ul>
                                 <li><a href="customer_login.php">Login</a></li>
                                 <li><a class="custom-b" href="customer_reg.php">Sign up</a></li>
                              </ul>
                           </div>
                        </div>
                        <div class="nav-b hidden-xs">
                           <div class="nav-box">
                                <ul>
                                    <li><a href="">How it works</a></li>
                                    <li><a href="partner_reg.php">Partners</a>
                                    </li>
                                </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
        </nav>
    </header>
    