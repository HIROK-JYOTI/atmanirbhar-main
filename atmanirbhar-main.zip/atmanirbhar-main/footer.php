<footer>
        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <p><img width="90" src="images/LOGO.png" alt="#" style="margin-top: -5px;" /> All Rights Reserved. Company Name © 2021</p>
                    </div>
                    
                </div>
            </div>
        </div>
    </footer>
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/jquery.steps.js"></script>
	<script src="js/main.js"></script>
     <!--main js--> 
</body>
</html>