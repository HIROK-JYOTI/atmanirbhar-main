<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <title>digital india</title>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!--enable mobile device-->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!--fontawesome css-->
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <!--bootstrap css-->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!--animate css-->
      <link rel="stylesheet" href="css/animate-wow.css">
      <!--main css-->
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/bootstrap-select.min.css">
      <link rel="stylesheet" href="css/slick.min.css">
      <!--responsive css-->
      <link rel="stylesheet" href="css/responsive.css">
   </head>
   <body>
      <header id="header" class="top-head">
         <!-- Static navbar -->
         <nav class="navbar navbar-default">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-md-4 col-sm-12 left-rs">
                     <div class="navbar-header">
                        <button type="button" id="top-menu" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false"> 
                        <span class="sr-only">Toggle navigation</span> 
                        <span class="icon-bar"></span> 
                        <span class="icon-bar"></span> 
                        <span class="icon-bar"></span> 
                        </button>
                        <a href="index.php" class="navbar-brand"><img src="images/LOGO.png"  alt="" /></a>
                     </div>
                     
                  </div>
                  <div class="col-md-8 col-sm-12">
                     <div class="right-nav">
                        <div class="login-sr">
                           <div class="login-signup">
                              <ul>
                                 <li><a href="index.php">Home</a></li>
                                 <li><a class="custom-b" href="logout.php">Logout</a></li>
                              </ul>
                           </div>
                        </div>
                        
                        <div class="nav-b hidden-xs">
                           <div class="nav-box">
                              <ul>
                                 <li><a href="adminindex.php">Administrator</a></li>
                                
                                 
                                 
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!--/.container-fluid --> 
         </nav>
      </header>
      <!-- Modal -->
     
     
      <div class="page-content-product">
         <div class="main-product">
            <div class="container">
                 <?php

require_once('config.php');
$select = "SELECT * FROM reg_employee";

$query = mysqli_query($con,$select);

?> 
   <table align="center" style="margin-top: 30px;">
                    <thead>
                    <tr bordercolor="#000000"> 
                    <th bordercolor="#000000"> <a href="add_employee.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:blue; font-size:18px;" >Add</button></a>
                    </th>
                    
                   
                    <th bordercolor="#000000"> <a href="update_employee.php">  <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:blue; font-size:18px; margin-left: 10px;" >Update</button></a>
                    </th>
                    
                   
                    <th bordercolor="#000000"> <a href="delete_employee.php">  <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:blue; font-size:18px; margin-left: 10px;" >Delete</button></a>
                    </th>
                    
                    </tr>
                    </thead>
            </table>
                  
            <table id="example" width="100%" cellspacing="0" style="margin-top: 35px; margin-bottom: 20px">
        <thead>
            <tr >
                <th height="2"><font color="white">Sr_no</font></th>			
                <th height="2"><font color="white">Employee Name</font></th>
                 <th height="2"><font color="white">Category </font></th>
                  <th height="2"><font color="white">District</font></th>
                   <th height="2"><font color="white">Pin</font></th>
                    <th height="2"><font color="white">Qualification</font></th>
                     <th height="2"><font color="white">Experience</font></th>
                      <th height="2"><font color="white">Mobile No</font></th>
                       <th height="2"><font color="white">Photo</font></th>
                        <th height="2"><font color="white">Document</font></th>
                
            </tr>
        </thead>
		 <tbody>
         
		  <?php
		 $i=0;
		 while($response = mysqli_fetch_assoc($query)) { ?> 
            <tr>
                <td><font color="#000000"><?php echo ++$i; ?> </font></td>
                <td><font color="#000000"><?php echo $response['name'] ?></font></td>
                 <td><font color="#000000"><?php echo $response['Category'] ?></font></td>
                  <td><font color="#000000"><?php echo $response['district'] ?></font></td>
                   <td><font color="#000000"><?php echo $response['pin'] ?></font></td>
                    <td><font color="#000000"><?php echo $response['qualification'] ?></font></td>
                     <td><font color="#000000"><?php echo $response['experience'] ?></font></td>
                      <td><font color="#000000"><?php echo $response['mobile'] ?></font></td>
                      <td><img src="requestimages/<?php echo $response['pic1']?>" width="100px" height="100px" /></td>
                        <td><img src="requestimages/<?php echo $response['pic2']?>" width="100px" height="100px" /></td>
                         <td><font color="#000000"><?php echo $response['status'] ?></font></td>
                      
                
            </tr>
		 <?php } ?>
		</tbody> 
		</table>
               </div>
             
            </div>
         </div>
      </div>
    
     
          
          
     
      <footer>
       
         <div class="copyright">
            <div class="container">
               <div class="row">
                  <div class="col-md-8">
                     <p><img width="90" src="images/LOGO.png" alt="#" style="margin-top: -5px;" /> All Rights Reserved. Company Name � 2021</p>
                  </div>
                 
               </div>
            </div>
         </div>
      </footer>
      <!--main js--> 
      <script src="js/jquery-1.12.4.min.js"></script> 
      <!--bootstrap js--> 
      <script src="js/bootstrap.min.js"></script> 
      <script src="js/bootstrap-select.min.js"></script>
      <script src="js/slick.min.js"></script> 
      <script src="js/wow.min.js"></script>
      <!--custom js--> 
      <script src="js/custom.js"></script>
   </body>
</html>