<link rel="stylesheet" href="css/style4.css"/>
   

<body class="form-v10">
 
<div class="page-content">
		<div class="form-v10-content">
           <form method="POST" enctype="multipart/form-data"> 
                  
                <table id="example" width="100%" cellspacing="0">
        
            <tr >
              
              		
                <th height="2"><font color="#000000">Category Name</font></th>
                <td> 
							<input type="text" name="category" id="name" class="form-control">
                            </td>
                            </tr>
                          
  <tr>            
                <th height="2"><font color="#000000">Upload Photo</font></th>
                <td> 
							<input type="file" name="t1" class="form-control">
                            </td>
                              <td> 
                              </tr>
                           
            
       
                            <tr>
                            <td></td>
                            <td>
                            <input type="submit" name="sbmt" value="ADD">
                            </td>
                            </tr>
                            
                          
                            
		
		</table>
        </form>
        <?php
		require_once('config.php');
if(isset($_POST["sbmt"]))
{
	
	$f1=0;
	
	
	
	$target_dir = "categoryimages/";
	//t4
	$target_file = $target_dir.basename($_FILES["t1"]["name"]);
	$uploadok = 1;
	$imagefiletype = pathinfo($target_file, PATHINFO_EXTENSION);
	//check if image file is a actual image or fake image
	$check=getimagesize($_FILES["t1"]["tmp_name"]);
	if($check!==false) {
		echo "file is an image - ". $check["mime"]. ".";
		$uploadok = 1;
	}else{
		echo "file is not an image.";
		$uploadok=0;
	}
	
	
	//check if file already exists
	if(file_exists($target_file)){
		echo "sorry,file already exists.";
		$uploadok=0;
	}
	
	//check file size
	if($_FILES["t1"]["size"]>500000){
		echo "sorry, your file is too large.";
		$uploadok=0;
	}
	
	
	//aloow certain file formats
	if($imagefiletype != "jpg" && $imagefiletype !="png" && $imagefiletype !="jpeg" && $imagefileype !="gif"){
		echo "sorry, only jpg, jpeg, Png & gif files are allowed.";
		$uploadok=0;
	}else{
		if(move_uploaded_file($_FILES["t1"]["tmp_name"], $target_file)){
			$f1=1;
	} else{
			echo "sorry there was an error uploading your file.";
		}
	}
	
	
	
	
	
		if($f1>0)
		{
	
	$s="insert into category(category,logo) values('" . $_POST["category"] ."','" . basename($_FILES["t1"]["name"]) . "')";
	mysqli_query($con,$s);

	echo "<script>alert('Record Save');</script>";
		}
	
		
}
?> 
         	</div>
	</div>

   
   
</body>
</html>