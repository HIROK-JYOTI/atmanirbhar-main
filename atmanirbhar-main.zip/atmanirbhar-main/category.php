
     <html>
     <head>
    <link rel="stylesheet" href="css/style4.css"/>
   
</head>
<body class="form-v10">
 
<div class="page-content">
		<div class="form-v10-content">
                    <?php

require_once('config.php');
$select = "SELECT * FROM category";

$query = mysqli_query($con,$select);

?> 
<div class="card">
  <div class="card-body">
 	<table align="left" style="margin-top: 20px; margin-left: 15px;">
                    <thead>
                    <tr bordercolor="#000000"> 
                    <th> <a href="add_category.php"> <button class="btn btn-primary" id="submit" type="submit" style="background-color:#FFF;  border: none;
  color: white;
  padding: 12px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;background-color: #008CBA; border-radius: 10%" >Add</button></a>
                    </th>
                    <th bordercolor="#000000"> <a href="update_category.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:#FFF; background-color:#FFF;  border: none;
  color: white;
  padding: 12px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;background-color: #008CBA; border-radius: 10%" >Update</button></a>
                    </th>
                      </th>
                    <th bordercolor="#000000"> <a href="delete_category.php"> <button class="btn btn-primary btn-xl text-uppercase" id="submit" type="submit" style="background-color:#FFF; background-color:#FFF;  border: none;
  color: white;
  padding: 12px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;background-color: #008CBA; border-radius: 10%" >Delete</button></a>
                    </th>
                    </tr>
                    </thead>
            </table>          
                 <br> <br> <br> <br>
            <table id="example" width="90%" cellspacing="0" align="center" style="border: 2px solid black; margin-top: 20px; padding: 5px; margin-bottom: 20px;">
        <thead>
            <tr >
                <th height="2"><font color="#000000">Sl_no</font></th>			
                <th height="2"><font color="#000000">Category Name</font></th>
                 
                       <th height="2"><font color="#000000">Logo</font></th>
                       
               
            </tr>
        </thead>
		 <tbody>
         
		 <?php
		 $i=0;
		 while($response = mysqli_fetch_assoc($query)) { ?> 
            <tr>
                <td><font color="#000000"><?php echo ++$i; ?> </font></td>
                <td><font color="#000000"><?php echo $response['category'] ?></font></td>
                
                      <td><img src="categoryimages/<?php echo $response['logo']?>" width="60px" height="60px" /></td>
                        
                
            </tr>
		 <?php } ?>
		</tbody> 
		</table> 
               </div>
              
            </div>
             </div>
              
            </div>
         </div>
      </div>
    
     
       
</body>
</html>     
          
     
    