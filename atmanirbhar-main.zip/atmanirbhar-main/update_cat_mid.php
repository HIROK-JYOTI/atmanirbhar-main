<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Atma Nirbhar Services</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="stylesheet/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="container">
  <div class="banner">
    <div class="banner-left">
    <div class="logozone"> <img src="images/logo1.PNG" height="60" width="300" alt="" border="0" /> </div>
      <div style="padding:203px 0px 0px 0px">
        <div class="topmenuzone">
          <div class="mainmenu">
            <ul>
              <li><a href="adminindex.php">HOME</a></li>
              <li><a href="category.php">CATEGORY</a></li>
             
              <li><a href="employee.php">EMPLOYEE</a></li>
                <li><a href="view_req_emp.php">APPROVAL</a></li>
                 <li><a href="view_feedback.php">FEEDBACK</a></li>
              <li style="border:none;"><a href="">BOOKING</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="banner-right">
      <div class="rightmenu">
        <div class="rightmenu1 rightmenulink"> <a href="index.php">Home</a> </div>
        <div class="rightmenu2 rightmenulink"> <a href="adminindex.php">Admin</a> </div>
        <div class="rightmenu3 rightmenulink"> <a href="logout.php">Logout</a> </div>
        <div class="clear"></div>
      </div>
      <div class="clear"></div>
      <div style="padding-top:15px; float:left">
        <div class="contactzone">
          <div class="contactleft"> <img src="images/contact.png" alt="" /> </div>
         <div class="contactright"><strong>Atma Nirbhar Services</strong><br />
           
            Silchar-06,Cachar ,Assam<br />
            <br />
            <span class="blueboldtxt">Phone:</span> +91-9435849354 <br />
            <span class="blueboldtxt">e-mail:</span> <span class="orangeboldtxt">atmanirbharservices<br/>@gmail.com</span></div>
          <div class="clear"></div>
        </div>
      </div>
    </div>
    <div class="clear"></div>
  </div>
  <div class="clear"></div>
  <div class="workzone">
    <div class="workzone-left">
      <div style="width:900px;">
        <div class="welcomezone">
          <div class="welcomeheading">
            <div>
              <h1>WELCOME TO <br />
                <span>Atma Nirbhar Services</span></h1>
            </div>
          </div>
          <div><font size="2" color="#000000">The service is offered through our website and you can hire professionals for pest control, carpentry, plumbing, professional cleaning, carpet and sofa cleaning, electrical repairs, laundry, home spa, and more. <br />
            <br />
           The company evaluates the eligibility of all enlisted service providers so that you can rest your worries. We also provide additional training and counseling for bridging any gap that exists in their service. </font></div>
          <div class="clear"></div>
        </div>
        <div class="clear"></div>
        <div class="box1">
          <div class="clientimg"></div>
          <div>
            <h2>WELCOME<span class="blueheading22">ADMIN<BR/></span> <span> TO OUR PORTAL</span></h2>
          </div>
          <div> <br />
         <?php include('regconnection.php');
$cat_id=$_GET['a'];
$q=mysqli_query($con,"select * from category where cat_id='$cat_id'");
$r=mysqli_fetch_array($q,MYSQLI_ASSOC);
//include('header/emptop.php'); //top header informaton here
?>
    <form name="f2" method="post" action="update_cat_action.php">
            <input type="hidden" name="cat_id" value="<?php echo $r['cat_id'];?>"/>    
               
                 <table id="example" width="100%" cellspacing="0">
        <thead>
            <tr >
              
              		
                <th height="2"><font color="#000000">Category Name</font></th>
                
            </tr>
            
        </thead>
		 <tbody>
         <tr>
         <td> 
         
			
						
							<input type="text" name="category" value="<?php echo $r['category'];?>" class="inpt"/>
                            </td>
                            </tr>
                            <tr>
                            <td>
                            <input type="submit" name="submit" value="UPDATE">
                            </td>
                            </tr>
                            
                            </tbody>
                            
		
		</table>
      
        </form>   
             </div>
          <div class="clear"></div>
        </div>
        <div class="clear"></div>
        <div class="box2">
          
          
          <div class="clear"></div>
        </div>
        <div class="clear"></div>
      </div>
    </div>
    <div class="clear"></div>
  </div>
  <div class="clear"></div>
  <div class="footer">
    <div class="footerlink"> Copyright (@)2020.. All rights reserved. Design by Unique Team </div>
  </div>
  <div class="clear"></div>
</div>
</body>
</html>
